from __future__ import annotations

import csv
import json
from collections import defaultdict
from dataclasses import asdict, dataclass
from hashlib import sha256
from pathlib import Path
from typing import Iterable

from .crypto import KeyRegistry
from .domain import (
    AttackType,
    DetectionEvent,
    EvidenceAttestation,
    EvidenceCase,
    EvidenceDirection,
    SourceKind,
)
from .evidence import sign_attestation


@dataclass(frozen=True)
class TraceBundle:
    seed: int
    events: list[DetectionEvent]
    rsu_cases: list[EvidenceCase]
    witness_cases: list[EvidenceCase]


def _hash_text(value: str) -> str:
    return sha256(value.encode("utf-8")).hexdigest()


def event_to_dict(event: DetectionEvent) -> dict:
    data = asdict(event)
    data["attack_type"] = event.attack_type.value
    data["source_kind"] = event.source_kind.value
    data["direction"] = int(event.direction)
    data["reason_codes"] = list(event.reason_codes)
    data["payload"] = dict(event.payload)
    return data


def event_from_dict(data: dict) -> DetectionEvent:
    raw = dict(data)
    raw["attack_type"] = AttackType(raw["attack_type"])
    raw["source_kind"] = SourceKind(raw["source_kind"])
    raw["direction"] = EvidenceDirection(int(raw["direction"]))
    raw["reason_codes"] = tuple(raw.get("reason_codes", []))
    raw["payload"] = raw.get("payload", {})
    return DetectionEvent(**raw)


def write_events_jsonl(events: Iterable[DetectionEvent], path: str | Path) -> Path:
    destination = Path(path)
    destination.parent.mkdir(parents=True, exist_ok=True)
    with destination.open("w", encoding="utf-8", newline="\n") as handle:
        for event in sorted(events, key=lambda item: (item.detected_at, item.event_id)):
            handle.write(json.dumps(event_to_dict(event), sort_keys=True, ensure_ascii=False) + "\n")
    return destination


def read_events_jsonl(path: str | Path) -> list[DetectionEvent]:
    events: list[DetectionEvent] = []
    with Path(path).open("r", encoding="utf-8") as handle:
        for line_number, line in enumerate(handle, start=1):
            if not line.strip():
                continue
            try:
                events.append(event_from_dict(json.loads(line)))
            except Exception as exc:
                raise ValueError(f"Invalid trace line {line_number}: {exc}") from exc
    return events


def write_events_csv(events: Iterable[DetectionEvent], path: str | Path) -> Path:
    destination = Path(path)
    destination.parent.mkdir(parents=True, exist_ok=True)
    rows = []
    for event in events:
        row = event_to_dict(event)
        row["reason_codes"] = "|".join(event.reason_codes)
        row["payload"] = json.dumps(event.payload, sort_keys=True, ensure_ascii=False)
        rows.append(row)
    if not rows:
        destination.write_text("", encoding="utf-8")
        return destination
    with destination.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)
    return destination


def _case_metadata(events: list[DetectionEvent]) -> tuple[str, str, AttackType, float, bool]:
    first = min(events, key=lambda event: event.detected_at)
    return (
        first.vehicle_id,
        first.pseudonym,
        first.attack_type,
        min(float(event.payload.get("case_opened_at", event.detected_at)) for event in events),
        first.ground_truth_malicious,
    )


def events_to_cases(events: Iterable[DetectionEvent], keys: KeyRegistry) -> tuple[list[EvidenceCase], list[EvidenceCase]]:
    grouped: dict[tuple[str, SourceKind], list[DetectionEvent]] = defaultdict(list)
    for event in events:
        grouped[(event.case_id, event.source_kind)].append(event)

    rsu_cases: list[EvidenceCase] = []
    witness_cases: list[EvidenceCase] = []
    for (case_id, source_kind), group in sorted(grouped.items(), key=lambda item: item[0]):
        vehicle_id, pseudonym, attack_type, opened_at, malicious = _case_metadata(group)
        case = EvidenceCase(
            case_id=case_id,
            vehicle_id=vehicle_id,
            pseudonym=pseudonym,
            attack_type=attack_type,
            opened_at=opened_at,
            ground_truth_malicious=malicious,
        )
        for index, event in enumerate(sorted(group, key=lambda item: (item.detected_at, item.event_id))):
            attestation = EvidenceAttestation(
                attestation_id=f"att-{_hash_text(event.event_id + '|' + event.detected_by)[:24]}",
                case_id=event.case_id,
                observation_root_id=event.observation_root_id,
                source_id=event.detected_by,
                source_kind=event.source_kind.value,
                validator_rsu_id=event.validator_rsu_id,
                administrative_domain_id=event.administrative_domain_id,
                sensor_modality=event.sensor_modality,
                geographic_cell=event.geographic_cell,
                attack_type=event.attack_type,
                direction=event.direction,
                detector_confidence=event.detector_confidence,
                source_reliability=event.source_reliability,
                freshness=event.freshness,
                verifiability=event.verifiability,
                independence=event.independence,
                observed_at=event.detected_at,
                evidence_hash=event.raw_evidence_hash,
                signature="",
                public_key_id="",
                validity=1,
                reason_codes=event.reason_codes,
            )
            case.add(sign_attestation(attestation, keys, event.detected_by))
        if source_kind == SourceKind.RSU:
            rsu_cases.append(case)
        else:
            witness_cases.append(case)
    return rsu_cases, witness_cases


def build_trace_bundle(events: Iterable[DetectionEvent], keys: KeyRegistry) -> TraceBundle:
    event_list = sorted(list(events), key=lambda event: (event.detected_at, event.event_id))
    if not event_list:
        raise ValueError("Cannot build a trace bundle from an empty event list")
    seeds = {event.seed for event in event_list}
    if len(seeds) != 1:
        raise ValueError("A TraceBundle must contain exactly one seed")
    rsu_cases, witness_cases = events_to_cases(event_list, keys)
    return TraceBundle(seed=next(iter(seeds)), events=event_list, rsu_cases=rsu_cases, witness_cases=witness_cases)


def calibration_rows(events: Iterable[DetectionEvent]) -> list[dict]:
    """Architecture-independent rows used for V-PUFT weight sensitivity."""
    rows = []
    for event in events:
        rows.append({
            "case_id": event.case_id,
            "observation_root_id": event.observation_root_id,
            "seed": event.seed,
            "attack_type": event.attack_type.value,
            "label": int(event.ground_truth_malicious),
            "validity": 1,
            "direction": int(event.direction),
            "source_id": event.detected_by,
            "source_kind": event.source_kind.value,
            "validator_rsu_id": event.validator_rsu_id,
            "administrative_domain_id": event.administrative_domain_id,
            "geographic_cell": event.geographic_cell,
            "sensor_modality": event.sensor_modality,
            "detector_confidence": event.detector_confidence,
            "source_reliability": event.source_reliability,
            "freshness": event.freshness,
            "verifiability": event.verifiability,
            "independence": event.independence,
            "observed_at": event.detected_at,
            "reason_codes": "|".join(event.reason_codes),
        })
    return rows
